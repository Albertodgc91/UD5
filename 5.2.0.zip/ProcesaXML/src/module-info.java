module ProcesaXML {
	requires java.xml;
}