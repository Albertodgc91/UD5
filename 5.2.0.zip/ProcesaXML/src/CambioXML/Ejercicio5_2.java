package CambioXML;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;

public class Ejercicio5_2 {

	private void guardarDocument(  Document document )
	  throws IOException, TransformerException{
		DOMSource domSource = new DOMSource(document );
		FileWriter fileWriter = new FileWriter(
				new File(RUTA_SALIDA + "output.xml"));
				
				
	}
	
	
}
