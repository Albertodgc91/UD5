module Lenguaje {
	requires java.xml;
}