package UD5;
import java.io.IOException;

import javax.xml.parsers.*;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.*;
import org.xml.sax.*;



public class Libros {
	 public static void main(String[] args) throws ParserConfigurationException, IOException, XPathExpressionException, SAXException{
	        
		 DocumentBuilderFactory dbt= DocumentBuilderFactory.newInstance();
		 DocumentBuilder db= dbt.newDocumentBuilder();
		 Document doc = db.parse("C:/Users/A22AlbertoGC/Desktop");
		 Element programacion = doc.getDocumentElement();
		 
		 
		 
		 
		 
             }

}


