package Dom_Escritura_Ejemplo;


	import java.io.FileWriter;
	import java.io.IOException;

	import javax.xml.parsers.DocumentBuilder;
	import javax.xml.parsers.DocumentBuilderFactory;
	import javax.xml.parsers.ParserConfigurationException;
	import javax.xml.transform.OutputKeys;
	import javax.xml.transform.Transformer;
	import javax.xml.transform.TransformerConfigurationException;
	import javax.xml.transform.TransformerException;
	import javax.xml.transform.TransformerFactory;
	import javax.xml.transform.dom.DOMSource;
	import javax.xml.transform.stream.StreamResult;

	import org.w3c.dom.Attr;
	import org.w3c.dom.Document;
	import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

	public class Ejercicio5_4 {

		private static final Node ElementExpediente = null;
		private void main(String args[]) {
			
			
			//metodo contruciion obj
			
			Document doc =crearDocument();
			Document doc2 =crearDocument();
			// metodo para escribir en el fichero
			
			guardarDocFile(doc,doc2);
		}
		
		private Document crearDocument () {
			Document doc = null;
			
		DocumentBuilderFactory dbf =DocumentBuilderFactory.newDefaultInstance();
	 try {
		DocumentBuilder	db =  dbf.newDocumentBuilder();
		 doc = db.newDocument();
		 
		 Element ElementExpedientes = doc.createElement("Expedientes");
		 Attr attrExpendientes = doc.createAttribute("Expediente");
		 
		 Attr attrTitulacion1  = doc.createAttribute("Tutulacion");
		 attrTitulacion1.setValue("DAW");
		 
		 Attr attrEstudiante1 = doc.createAttribute("Estudiante");
		 attrEstudiante1.setValue("Ferran Soler Puig");
		
		Element Modulos = doc.createElement("Modulos");
		
		Attr attrModulo   = doc.createAttribute("Progamacion ");
		 Text textAprobado = doc.createTextNode("Aprobado");
		 ((Attr) textAprobado).setValue("True");
		Text textCurso = doc.createTextNode("Curso");
		((Attr) textCurso).setValue("Primero");
		
		Attr attrModulo3   = doc.createAttribute("Desarrollo web en entorno cliente");
		 Text textAprobado3 = doc.createTextNode("Aprobado");
		 ((Attr) textAprobado3).setValue("True");
		Text textCurso3 = doc.createTextNode("Curso");
		((Attr) textCurso3).setValue("Segundo");
		
		Attr attrModulo2   = doc.createAttribute("Desarrollo web en entorno servidor  ");
		 Text textAprobado2 = doc.createTextNode("Aprobado");
		 ((Attr) textAprobado2).setValue("False");
		Text textCurso2 = doc.createTextNode("Curso");
		((Attr) textCurso2).setValue("Primero");
		
	
		 
		 
	
		 
		 ElementExpedientes.setAttributeNode(attrTitulacion1);
		 ElementExpedientes.setAttributeNode(attrEstudiante1);
		 ElementExpedientes.setAttributeNode(attrModulo);
		 ElementExpedientes.setAttributeNode(attrModulo2);
		 ElementExpedientes.setAttributeNode(attrModulo3);
		 
		 
		 ElementExpedientes.appendChild(attrTitulacion1);
		 ElementExpediente.appendChild(attrExpendientes);
		 
		 
		 doc.appendChild(attrExpendientes);
		 
		 
		 
	
		 
		 
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
		
			
			return doc;
		} 
		private Document crearDocument2 () {
			Document doc2 = null;
			
		DocumentBuilderFactory dbf =DocumentBuilderFactory.newDefaultInstance();
	 try {
		DocumentBuilder	db2 =  dbf.newDocumentBuilder();
		 doc2 = db2.newDocument();
		 
		 Element ElementExpedientes = doc2.createElement("Expedientes");
		 Attr attrExpendientes = doc2.createAttribute("Expediente");
		 
		 Attr attrTitulacion1  = doc2.createAttribute("Tutulacion");
		 attrTitulacion1.setValue("DAW");
		 
		 Attr attrEstudiante1 = doc2.createAttribute("Estudiante");
		 attrEstudiante1.setValue(">Ainhoa Gárate Lizarraga");
		
		Element Modulos = doc2.createElement("Modulos");
		
		Attr attrModulo   = doc2.createAttribute("Lenguaje de marcas y sistemas de gestion informatica  ");
		 Text textAprobado = doc2.createTextNode("Aprobado");
		 ((Attr) textAprobado).setValue("True");
		Text textCurso = doc2.createTextNode("Curso");
		((Attr) textCurso).setValue("Primero");
		
		Attr attrModulo3   = doc2.createAttribute("Sistemas Informaticos  ");
		 Text textAprobado3 = doc2.createTextNode("Aprobado");
		 ((Attr) textAprobado3).setValue("True");
		Text textCurso3 = doc2.createTextNode("Curso");
		((Attr) textCurso3).setValue("Primero");
		
		Attr attrModulo2   = doc2.createAttribute("Programacon multimedia y dispositivos movils    ");
		 Text textAprobado2 = doc2.createTextNode("Aprobado");
		 ((Attr) textAprobado2).setValue("True");
		Text textCurso2 = doc2.createTextNode("Curso");
		((Attr) textCurso2).setValue("Primero");
		
	
		 
		 
	
		 
		 ElementExpedientes.setAttributeNode(attrTitulacion1);
		 ElementExpedientes.setAttributeNode(attrEstudiante1);
		 ElementExpedientes.setAttributeNode(attrModulo);
		 ElementExpedientes.setAttributeNode(attrModulo2);
		 ElementExpedientes.setAttributeNode(attrModulo3);
		 
		 
		 ElementExpedientes.appendChild(attrTitulacion1);
		 ElementExpediente.appendChild(attrExpendientes);
		 
		 
		 doc2.appendChild(attrExpendientes);
		 
	 }
		}
	
	 
		
		 
		
		
		
		private static void guardarDocFile (Document doc, Document doc2) {
			DOMSource domS = new DOMSource(doc);
			try {
				FileWriter fw = new FileWriter("./libro.xml");
				StreamResult sr=new StreamResult(fw);
				TransformerFactory tf = TransformerFactory.newInstance();
				
				Transformer tr = tf.newTransformer();
				tr.setOutputProperty(OutputKeys.INDENT, "yes");
				
				
				tr.transform(domS, sr);
				
			} catch (IOException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		}
		 
	}

