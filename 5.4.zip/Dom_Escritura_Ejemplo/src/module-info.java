module Dom_Escritura_Ejemplo {
	requires java.xml;
}