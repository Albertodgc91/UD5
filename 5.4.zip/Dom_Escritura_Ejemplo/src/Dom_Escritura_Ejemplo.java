package Dom_Escritura_Ejemplo;

import java.io.FileWriter;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Dom_Escritura_Ejemplo {

	private void main(String args[]) {
		
		
		//metodo contruciion obj
		
		Document doc =crearDocument();
		// metodo para escribir en el fichero
		
		guardarDocFile(doc);
	}
	
	private Document crearDocument () {
		Document doc = null;
		
	DocumentBuilderFactory dbf =DocumentBuilderFactory.newDefaultInstance();
 try {
	DocumentBuilder	db =  dbf.newDocumentBuilder();
	 doc = db.newDocument();
	 
	 Element ElementLibros = doc.createElement("libros");
	 Attr attrLibros = doc.createAttribute("editorial");
	 attrLibros.setValue("para info");
	 
	 
	 Element elementLibro = doc.createElement("libro");
	 Attr attrIdLibro1 = doc.createAttribute("id");
	 attrIdLibro1.setValue("1");
	 
	 
	 Attr attrDigitalLibro1 = doc.createAttribute("Digital");
	 attrDigitalLibro1.setValue("false");
	 
	 Attr attrPapelLibro1= doc.createAttribute("Papel");
	 attrPapelLibro1.setValue("True");
	 
	 Element elementTitulo1 = doc.createElement("Titulo");

	 Text textTitulo1 = doc.createTextNode("Lenguaje de marcas y sistemas de gestion informatica  ");
	 
	 elementTitulo1.appendChild(textTitulo1);
	 
	 elementLibro.setAttributeNode(attrIdLibro1);
	 elementLibro.setAttributeNode(attrDigitalLibro1);
	 elementLibro.setAttributeNode(attrPapelLibro1);
	 
	 elementLibro.appendChild(elementTitulo1);
	 ElementLibros.appendChild(elementLibro);
	 
	 
	 doc.appendChild(elementLibro);
	 
	 
} catch (ParserConfigurationException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}	
		
		
		return doc;
	} 
	private static void guardarDocFile (Document doc) {
		DOMSource domS = new DOMSource(doc);
		try {
			FileWriter fw = new FileWriter("C:/Users/A22AlbertoGC");
			StreamResult sr=new StreamResult(fw);
			TransformerFactory tf = TransformerFactory.newInstance();
			
			Transformer tr = tf.newTransformer();
			tr.setOutputProperty(OutputKeys.INDENT, "yes");
			
			
			tr.transform(domS, sr);
			
		} catch (IOException | TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	 
}
