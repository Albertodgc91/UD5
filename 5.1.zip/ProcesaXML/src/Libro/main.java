package Libro;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class main {

	private static void main(String args[]) {
		String filex = "link";
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document doc = documentBuilder.parse(filex);
			procesaDigital(doc);
		} catch (ParserConfigurationException | SANExceptio | IOException e) {

			((Throwable) e).printStackTrace();

		}
	}

	private static void procesaDigital(Document doc) {

		Element libros = doc.getDocumentElement();
		NodeList listaLibros = libros.getChildNodes();

		for (int i = 0; i < listaLibros.getLength(); i++) {
			Node libroActual = listaLibros.item(i);

			if (libroActual.getNodeType() == Node.ELEMENT_NODE) {
				Element elementLibroAc = (Element) libroActual;

				Boolean digital = Boolean.parseBoolean(elementLibroAc.getAttribute("Digital"));

				if (digital) {
					System.out.println(elementLibroAc.getFirstChild().getNodeValue());

				}
			}
		}
	}

}
